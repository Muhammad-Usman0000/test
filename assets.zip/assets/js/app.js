// ======================FIRST TIME ====================================
const questions = [
  {
    que: "which of the markup language?",
    a: "HMTL",
    b: "css",
    c: "Js",
    d: "React",
    correct: "a",
  },
  {
    que: "which is framework of js?",
    a: "js",
    b: "css",
    c: "php",
    d: "none",
    correct: "d",
  },
  {
    que: "which of the styling language?",
    a: "HMTL",
    b: "css",
    c: "Js",
    d: "React",
    correct: "b",
  },
];

let index = 0;
let total = questions.length;
let right = 0;
let wrong = 0;
const quesBox = document.getElementById("quesBox");
const optionInputs = document.querySelectorAll(".options");
const loadQustion = () => {
  if (index === total) {
    return endQuiz();
  }
  reset();
  const data = questions[index];

  quesBox.innerText = `${index + 1}) ${data.que}`;
  optionInputs[0].nextElementSibling.innerText = data.a;
  optionInputs[1].nextElementSibling.innerText = data.b;
  optionInputs[2].nextElementSibling.innerText = data.c;
  optionInputs[3].nextElementSibling.innerText = data.d;
};

const submitQuiz = () => {
  const data = questions[index];
  const ans = getAnswer();
  if (ans == data.correct) {
    right++;
  } else {
    wrong++;
  }
  index++;
  loadQustion();
  return;
};

const getAnswer = () => {
  let answer;
  optionInputs.forEach((input) => {
    if (input.checked) {
      answer = input.value;
      // console.log(input.value);
    }
  });
  return answer;
};
const reset = () => {
  optionInputs.forEach((input) => {
    input.checked = false;
  });
};

const endQuiz = () => {
  document.getElementById("box").innerHTML = `
    <div style="text-align:center"></div>
    <h3> Thank you! for playing this quiz </h3>
    <h2> ${right} / ${total} are correct </h2>

    `;
};
loadQustion();

// ======================SECOND TIME ====================================


// const questions = [
//     {
//     que: "which of the markup language?",
//     a: "HMTL",
//     b: "HLMT",
//     c: "HTLM",
//     d: "HTML",
//     correct: "d",
//   },
//   {
//     que: "which of the Style language?",
//     a: "HMTL",
//     b: "CSS",
//     c: "HTLM",
//     d: "HTML",
//     correct: "d",
//   }, {
//     que: "which of the Functional language?",
//     a: "HMTL",
//     b: "HLMT",
//     c: "JavaScript",
//     d: "HTML",
//     correct: "d",
//   },
// ];

// let index = 0;
// let total = questions.length;
// let right = 0;
// let wrong = 0;

// const quesBox = document.getElementById("quesBox");
// const optionInputs = document.querySelectorAll(".options");

// const loadQustion =  () => {
//   if (index === total) {
//     return endQuiz();
//   }
//   reset();
//   const data = questions[index];

//   quesBox.innerText = `${index + 1}) ${data.que}`;
//   optionInputs[0].nextElementSibling.innerHTML = data.a;
//   optionInputs[1].nextElementSibling.innerHTML = data.b;
//   optionInputs[2].nextElementSibling.innerHTML = data.c;
//   optionInputs[3].nextElementSibling.innerHTML = data.d;
// };
// const submitQuiz = () => {
// const data = questions[index];
// const ans = getAnwser();
// if(ans == data.correct){
//     right++;
// }else{
//     wrong++;
// };
// index++;
// loadQustion();
// return;
// };

// const getAnwser = () => {
//     let answer;
//     optionInputs.forEach((input) => {
//         if(input.checked){
//             answer = input.value;
//         }
//     });
//     return answer;
// };

// const reset = () => {
//     optionInputs.forEach((input) => {
//         input.checked = false;
//     });
// };

// const endQuiz = () =>{
//     document.getElementById("box").innerHTML = `<div style="text-align:center">  
//     <h3> Thank you! for playing this quiz </h3>
//     <h2> ${right} / ${total} are correct </h2>
//     </div>`;
// };
// loadQustion();









